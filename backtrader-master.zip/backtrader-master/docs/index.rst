.. backtrader documentation master file, created by
   sphinx-quickstart on Mon Feb 23 13:28:32 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to backtrader's documentation!
======================================

The documentation lives now at:

  - http://www.backtrader.com/docu/
