.. _dataautoref:

Data Feeds Reference
====================

.. databaseref::
