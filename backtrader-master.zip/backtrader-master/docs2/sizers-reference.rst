
Sizers Reference
################

.. currentmodule:: backtrader.sizers


FixedSize
*********

.. autoclass:: FixedSize


FixedReverser
*************

.. autoclass:: FixedReverser


PercentSizer
************

.. autoclass:: PercentSizer


AllInSizer
**********

.. autoclass:: AllInSizer
