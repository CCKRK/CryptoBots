.. _stratautoref:

Strategies Reference
====================

Reference for the built-in strategies

.. stratref::
