
Filters Reference
#################

.. currentmodule:: backtrader.filters

SessionFilter
*************

.. autoclass:: SessionFilter

SessionFilterSimple
*******************

.. autoclass:: SessionFilterSimple

SessionFilller
**************

.. autoclass:: SessionFiller

CalendarDays
************

.. autoclass:: CalendarDays

BarReplayer_Open
****************

.. autoclass:: BarReplayer_Open

DaySplitter_Close
*****************

.. autoclass:: DaySplitter_Close

HeikinAshi
**********

.. autoclass:: HeikinAshi


HeikinAshi
**********

.. autoclass:: Renko
