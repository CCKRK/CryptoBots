

Live Data Feeds and Live Trading
################################

Starting with release **1.5.0** ``backtrader`` supports live data and live
trading.

.. toctree::
   :maxdepth: 1

   ib/ib.rst
   vc/vc.rst
   oanda/oanda.rst
